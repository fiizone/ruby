x = 15

if x <= 10
  puts "10 or below"
elsif x >= 20
  puts "20 or above"
else
  puts "Between 10 and 20"
end
